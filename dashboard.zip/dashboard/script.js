// Function to display popup
function openPopup() {
  document.getElementById("thankyou-popup-overlay").style.display = "block";
  document.getElementById("thankyou-popup").style.display = "block";
}

// Function to close popup
function closePopup() {
  document.getElementById("thankyou-popup-overlay").style.display = "none";
  document.getElementById("thankyou-popup").style.display = "none";
}

// Add event listener to form submission
document
  .getElementById("download-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Show the popup message
    openPopup();

    // Hide the popup message after 3 seconds and then redirect
    setTimeout(function () {
      closePopup();
      // Redirect to the video URL
      window.location.href = "https://dashcare.info/video";
    }, 3000); // 3 seconds
  });
